#!/bin/sh  
exe="jlu-drcom-client-qt"
des="/home/sea/Nutstore/jlu-drcom-client-qt/drcom-qt-bin-v0.1" 
deplist=$(ldd $exe | awk  '{if (match($3,"/")){ printf("%s "),$3 } }')  
cp $deplist $des
